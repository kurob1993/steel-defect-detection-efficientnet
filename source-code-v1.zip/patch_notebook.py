import json

with open("steel-defect-detection-v1.ipynb", "r") as f:
    nb = json.load(f)

with open("cell3_optimized.py", "r") as f:
    cell3_code = f.read()

cell4_code = """# Cell 4: Quick sanity checks
print('submission rows:', len(submission))
print('empty masks:', (submission['EncodedPixels'] == '').sum())
print('non-empty masks:', (submission['EncodedPixels'] != '').sum())

expected = len(test_images) * 4  # 5506 × 4 = 22024
assert len(submission) == expected, f'Row count mismatch: {len(submission)} vs {expected}'
assert list(submission.columns) == ['ImageId_ClassId', 'EncodedPixels'], f'Wrong columns: {submission.columns.tolist()}'
print('✅ Submission format OK')"""

for cell in nb["cells"]:
    if cell["cell_type"] == "code":
        source = "".join(cell["source"])
        if "# Cell 3: Inference test_images + build submission.csv" in source:
            cell["source"] = [line + ("\n" if not line.endswith("\n") else "") for line in cell3_code.split("\n")]
        elif "# Cell 4: Quick sanity checks" in source:
            cell["source"] = [line + ("\n" if not line.endswith("\n") else "") for line in cell4_code.split("\n")]

with open("steel-defect-detection-v1.ipynb", "w") as f:
    json.dump(nb, f, indent=1)

print("Notebook patched successfully!")
